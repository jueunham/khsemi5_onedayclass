package one.dao.face;

public interface ManagerDao {

}
