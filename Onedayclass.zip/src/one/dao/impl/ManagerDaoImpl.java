package one.dao.impl;

import one.dao.face.ManagerDao;

public class ManagerDaoImpl implements ManagerDao {


}
