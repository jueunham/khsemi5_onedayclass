package one.service.impl;


import one.service.face.ManagerService;

public class ManagerServiceImpl implements ManagerService {


}
