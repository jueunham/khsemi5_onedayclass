package one.service.face;

public interface ManagerService {

}
