package one.controller.manager.board;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;


@WebServlet("/admin/board/notice/write")
public class BoardNoticeWriteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    


}
