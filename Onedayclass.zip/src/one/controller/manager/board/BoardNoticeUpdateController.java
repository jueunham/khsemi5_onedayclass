package one.controller.manager.board;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet("/admin/board/notice/update ")
public class BoardNoticeUpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

}
