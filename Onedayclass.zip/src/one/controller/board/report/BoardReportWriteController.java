package one.controller.board.report;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

/**
 * Servlet implementation class BoardReportWriteController
 */
@WebServlet("/board/report/write")
public class BoardReportWriteController extends HttpServlet {
	private static final long serialVersionUID = 1L;

}
