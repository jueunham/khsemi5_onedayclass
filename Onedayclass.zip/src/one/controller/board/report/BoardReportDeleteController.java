package one.controller.board.report;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

/**
 * Servlet implementation class BoardReportDeleteController
 */
@WebServlet("/board/report/delete")
public class BoardReportDeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;

}
