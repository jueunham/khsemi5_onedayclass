package one.controller.board.bulletin;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

/**
 * Servlet implementation class BoardBulletinViewController
 */
@WebServlet("/board/bulletin/view")
public class BoardBulletinViewController extends HttpServlet {
	private static final long serialVersionUID = 1L;

}
