package one.controller.board.bulletin;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

/**
 * Servlet implementation class DownloadController
 */
@WebServlet("/file/download")
public class DownloadController extends HttpServlet {
	private static final long serialVersionUID = 1L;

}
